if __name__ == '__main__':
    n = int(input())
    
    ans = ''

    for i in range(1,n+1):
        ans += str(i)
    
    print(ans)
    