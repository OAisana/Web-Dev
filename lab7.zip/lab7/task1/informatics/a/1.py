from math import sqrt

a = int(input())
b = int(input())

print(sqrt(a * a + b * b))
