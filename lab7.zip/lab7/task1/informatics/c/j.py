res = 0
for x in range(0, 100):
    a = int(input())
    res += a
print(res)
