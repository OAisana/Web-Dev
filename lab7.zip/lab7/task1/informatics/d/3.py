a = int(input())
res = ""
n = 1
while n <= a:
    res += str(n) + " "
    n *= 2
print(res)
