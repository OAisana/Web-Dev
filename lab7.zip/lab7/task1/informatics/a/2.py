a = int(input())


print(f"The next number for the number {a} is {a+1}.")
print(f"The previous number for the number {a} is {a-1}.")
