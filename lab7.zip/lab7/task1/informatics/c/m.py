a = int(input())
res = 0
for x in range(0, a):
    b = int(input())
    if b == 0:
        res += 1
print(res)
