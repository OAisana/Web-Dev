a = int(input())
b = int(input())

if a == b:
    print(0)
elif a > b:
    print(1)
else:
    print(2)
